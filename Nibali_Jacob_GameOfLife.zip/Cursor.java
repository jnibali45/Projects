import java.awt.Color;
import java.awt.event.KeyEvent;

public class Cursor {
	int xPos, yPos, oriX, oriY;
	
	Cursor(int x, int y) {
		xPos = x;
		yPos = y;
	}
	
	public void logic() {
		boolean check = false;
		this.oriX = this.xPos;
		this.oriY = this.yPos;
		
		if(KeyInput.keys.contains(KeyEvent.VK_UP)) {
			this.xPos -= 1;
		}
		
		if(KeyInput.keys.contains(KeyEvent.VK_DOWN)) {
			this.xPos += 1;
		}
		
		if(KeyInput.keys.contains(KeyEvent.VK_LEFT)) {
			this.yPos -= 1;
		}
		
		if(KeyInput.keys.contains(KeyEvent.VK_RIGHT)) {
			this.yPos += 1;
		}
		
		
		
		if(KeyInput.keys.contains(KeyEvent.VK_P)) {
			GameDiver.paused = !GameDiver.paused;
			KeyInput.keys.remove(new Integer(KeyEvent.VK_P));
		}
		
		if(this.xPos > GameDiver.size - 1) {
			this.xPos = GameDiver.size - 1;
		}
		
		if(this.xPos < 0) {
			this.xPos = 0;
		}
		
		if(this.yPos > GameDiver.size * 2 - 1) {
			this.yPos = GameDiver.size * 2 - 1;
		}
		
		if(this.yPos < 0) {
			this.yPos = 0;
		}
		
		if(KeyInput.keys.contains(KeyEvent.VK_SPACE)) {
			GameDiver.states[this.xPos][this.yPos].state = !GameDiver.states[this.xPos][this.yPos].state;
		}
	}
	
	public void draw() {
		GameDiver.states[this.oriX][this.oriY].draw();
		GameDiver.map.setColor(xPos, yPos, Color.RED);
	}
}
