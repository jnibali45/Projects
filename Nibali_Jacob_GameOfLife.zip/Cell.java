import java.awt.Color;

public class Cell {
	public boolean state;
	int xPos, yPos, neighbors;
	
	Cell(int x, int y) {
		this.state = false;
		this.xPos = x;
		this.yPos = y;
	}
	
	public void initialLogic() {
		this.neighbors = 0;
		for(int i = -1; i < 2; i++) {
			for(int j = -1; j < 2; j++) {
				if((i != 0 || j != 0) && this.xPos + i < GameDiver.map.getHt() &&
					this.yPos + j < GameDiver.map.getWd() && this.xPos + i >= 0 &&
					this.yPos + j >= 0 && GameDiver.states[this.xPos + i][this.yPos + j].state) {
					this.neighbors += 1;
				}
			}
		}
		
	}
	
	public void finalLogic() {
		if(this.state && this.neighbors < 2) {
			this.state = false;
		} else if (this.state && this.neighbors > 3) {
			this.state = false;
		} else if (!this.state && this.neighbors == 3) {
			this.state = true;
		} else if (this.state && (this.neighbors == 2 || this.neighbors == 3)) {
			this.state = true;
		}
	}
	
	public void draw() {
		if (this.state) {
			GameDiver.map.setColor(this.xPos, this.yPos, Color.BLACK);
		} else {
			GameDiver.map.setColor(this.xPos, this.yPos, Color.WHITE);
		}
	}

}
