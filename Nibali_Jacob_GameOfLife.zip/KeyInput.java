import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.awt.event.KeyListener;

public class KeyInput implements KeyListener {
	public static ArrayList<Integer> keys = new ArrayList<Integer>();
	
	public KeyInput(MyGrid map) {
		map.addKeyListener(this);
		map.setFocusable(true);
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if(!this.keys.contains(new Integer(e.getKeyCode()))) {
			this.keys.add(new Integer(e.getKeyCode()));
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		if(this.keys.contains(e.getKeyCode())) {
			this.keys.remove(new Integer(e.getKeyCode()));
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	
}
