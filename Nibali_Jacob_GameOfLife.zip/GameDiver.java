import java.util.concurrent.TimeUnit;

public class GameDiver {
	public static MyGrid map;
	static int size = 50;
	public static Cell[][] states;
	public static boolean paused = true;
	
	public static void main(String[] args) throws InterruptedException {
		GameDiver.map = new MyGrid(size);
		GameDiver.states = new Cell[map.getHt()][map.getWd()];
		
		for(int i = 0; i < map.getHt(); i++) {
			for(int j = 0; j < map.getWd(); j++) {
				states[i][j] = new Cell(i, j);
				states[i][j].draw();
			}
		}
		KeyInput kl = new KeyInput(map);
		Cursor player = new Cursor((map.getHt() - 1)/2, map.getWd()/2);
		while(true) {
			player.logic();
			
			if(!paused) {
				for(int i = 0; i < map.getHt(); i++) {
					for(int j = 0; j < map.getWd(); j++) {
						states[i][j].initialLogic();
					}
				}
				
				for(int i = 0; i < map.getHt(); i++) {
					for(int j = 0; j < map.getWd(); j++) {
						states[i][j].finalLogic();
					}
				}
				
				for(int i = 0; i < map.getHt(); i++) {
					for(int j = 0; j < map.getWd(); j++) {
						states[i][j].draw();
					}
				}		
				
			}
			
			player.draw();
			map.repaint();
			TimeUnit.MILLISECONDS.sleep(50);
		}
	}
}
